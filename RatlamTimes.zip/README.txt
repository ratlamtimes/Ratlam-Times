RatlamTimes - Generated Website
---------------------------------
Files:
- index.html
- style.css
- script.js

Usage:
1. Download the zip and extract.
2. Open index.html in a browser to view the site.
3. To deploy, upload the folder contents to any static hosting (Netlify, Vercel, GitHub Pages, etc.).

Notes:
- Images use placeholder URLs (via.placeholder.com). Replace with your own images in an 'images/' folder and update paths.
- If you want help deploying to GitHub Pages / Netlify, tell me and I will provide step-by-step instructions.